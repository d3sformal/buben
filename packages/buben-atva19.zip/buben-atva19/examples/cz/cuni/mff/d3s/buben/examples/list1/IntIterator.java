package cz.cuni.mff.d3s.buben.examples.list1;

public interface IntIterator
{
	boolean hasNext();
	int next();
	void remove();
}
