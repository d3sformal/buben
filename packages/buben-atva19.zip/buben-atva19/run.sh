#!/bin/bash

ANT_DIR="tools"

if [ -z "$JAVA_HOME" ]; then
  export JAVA_HOME="$(readlink -f "$(which javac)" 2> /dev/null | sed 's/\/bin\/javac$//' 2> /dev/null)"
fi

JAVAC_JAR="$JAVA_HOME/lib/tools.jar"
if [ ! -f "$JAVAC_JAR" ]; then
  echo "no bytecode compiler found: $JAVAC_JAR"
  exit 1
fi

CP="${JAVAC_JAR}:${ANT_DIR}/ant.jar:${ANT_DIR}/ant-launcher.jar"

java -classpath "${CP}" org.apache.tools.ant.Main "run.benchmarks.transform"
java -classpath "${CP}" org.apache.tools.ant.Main "run.benchmarks.original"


